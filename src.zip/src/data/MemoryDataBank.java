/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.Programador;
import model.Sexo;

/**
 *
 * @author crfranco
 */
public class MemoryDataBank implements IDao<Programador>{
    
    private List<Programador> memoryDataBank = new ArrayList<>(); 

    @Override
    public void save(Programador t) {
        String message = "";
        if(!memoryDataBank.contains(t)){
        memoryDataBank.add(t);
            message = "Programador cadastrado com sucesso!";
              JOptionPane.showMessageDialog(null, message);
    }
        
        else{
             message = "Programador já cadastrado";
              JOptionPane.showMessageDialog(null, message);
        }
        
    
    }

    @Override
    public Programador getOne(int id) {
        Programador p = null;
        if(memoryDataBank.contains(id)){
            p =  memoryDataBank.get(id);
            String message = "Programador já cadastrado" + p;
              JOptionPane.showMessageDialog(null, message);
        }
        return p;
    }

    @Override
    public List<Programador> list() {
        
        return null;
    }

    @Override
    public void update(Programador t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(int id) {
        memoryDataBank.remove(id);
        String message = "Programador excluido.";
              JOptionPane.showMessageDialog(null, message);
        
    }
    
}
